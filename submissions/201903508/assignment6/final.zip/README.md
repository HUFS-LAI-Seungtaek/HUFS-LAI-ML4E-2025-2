# 실행 방법 Guide
1. 필요한 라이브러리를 설치합니다: pip install -r requirements.txt
2. inference.ipynb 파일을 엽니다.
3. 코드를 실행하면 models 폴더에 있는 모델을 불러와 예측을 수행합니다.