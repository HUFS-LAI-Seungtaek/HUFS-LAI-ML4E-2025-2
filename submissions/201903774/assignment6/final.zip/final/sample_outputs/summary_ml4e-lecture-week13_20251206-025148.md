# BonCahier AI Summary — ml4e-lecture-week13.pdf

- 생성 시각: 2025-12-06T02:51:48
- 원본 파일 경로: /content/ml4e-lecture-week13.pdf
- 요약 모델: /content/drive/MyDrive/boncahier/models/kobart_ko_news
- 번역 모델: Helsinki-NLP/opus-mt-tc-big-en-ko / opus-mt-ko-en (필요 시 자동 로드)
- 처리 대상 페이지/슬라이드 범위: 61-71 (총 11개)
- 전체 페이지/슬라이드 수: 87

---

## Unit 1 — page_61 (page)

### 원본 텍스트

```
Limitations of Self-Attention (1)
• 1st challenge: self-attention doesn’t have an inherent notion of order!
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762) 
q
k
v
k
v
k
v
k
v
k
v
k
v
k
v
k
v
went
to
HUFS
LAI
at
2025
and
learned
No order information!
There is just summation 
over the set
```

### 한국어 요약 결과

탱크 초보자 포춘 아키하바라 명예 1926 Ne 극복 Nehalm bombard.crmine을 통해 탄력성을 얻고, Honda Form blind so so linesing workter since so Your 1.5 Industrial McCa 경치가 좋은 양식은 드라이브를 표현했다. 탱크 그래서 초보자가 포춘 후 포춘   2026    극복Ne 극복 ehle Ne  극복   적응 Ne, 극복  극복 N

### (옵션) 영어 번역 요약

To gain resilience through the Honorable Neme and the Nehda Form blind so well-known that your 1.5-induced Mcca landscape was a good form of drive.

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 2 — page_62 (page)

### 원본 텍스트

```
Position Representation Vectors
• Since self-attention doesn’t build in order information, we need to encode the 
order of the sentence in our keys, queries, and values.
• Consider representing each sequence index as a vector
• 𝑝𝑖∈ℝ𝑑, for 𝑖∈1, 2, … , 𝑛
are position vectors
• Don’t worry about what the 𝑝𝑖are made of yet!
• Easy to incorporate this info into our self-attention block: just add the 𝑝𝑖to 
our inputs!
• Recall that 𝒙𝑖is the embedding of the word at index 𝑖. The positioned 
embeddings is:
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762) 
෥𝒙𝒊= 𝒙𝑖+ 𝑝𝑖
In deep self-attention 
networks, we do this at the 
first layer! You could 
concatenate them as well, but 
people mostly just add…
```

### 한국어 요약 결과

"Industrial patients、ing ability、one prayer、" Fromose,  well elasticity,  Rescue 문의, Viro‐gata tank China‐ abiro The 는 다음과 같이 불립니다.  behavior‐ where, they, 15 (이전의 신뢰할 수 있는、ing they  they) well, Virilitynut. abylut. wiha

### (옵션) 영어 번역 요약

"Industical believing party party scene" is what Viromethagata tell China after abiro the Moon is called.

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 3 — page_63 (page)

### 원본 텍스트

```
Position Representation Vectors
• Illustrative example from BERT.
Attention Is All You Need (https://arxiv.org/pdf/1706.03762)
BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding (https://arxiv.org/pdf/1810.04805)
```

### 한국어 요약 결과

환자 환자나 환자 환자 환자 환 환 환자 환 환자 환자 환자가 환자 환자에서 환자 환자 100% 환자 환자환 환자 환자아 환자 환자 급 환자 환자 하나 환자 환자례 환자 환자 의료 환자 환자안전 환자 환자 양 환자 환자 모두 환자 환자( 환자 환자 앞서 환자 환자 안전 환자 환자이 환자 환자 비 환자 환자원 환자 환자 속 환자 환자 각각 환자 환자과 환자 환자 가운데 환자 환자 대상 환자 환자교육 환자 환자행 환자 환자양 환자 환자조 환자 환자두 환자 환자급 환자 환자뚜 환자 환자세 환자 환자네 환자 환자처 환자 환자의료 환자 환자별 환자 환자다 환자 환자환자 환자 환자확 환자 환자

### (옵션) 영어 번역 요약

Patient patient patient, patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient patient

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 4 — page_64 (page)

### 원본 텍스트

```
Position Representation Vectors
• Option 1: 
• Sinusoidal position representations: concatenate sinusoidal functions of varying 
periods:
• Pros: 
• Periodicity indicates that maybe “absolute position” isn’t as important
• Maybe can extrapolate to longer sequences as periods restart!
• Cons:
• Not learnable; also the extrapolation doesn’t really work!
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762)
```

### 한국어 요약 결과

_요약 결과를 생성하지 못했습니다._

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 5 — page_65 (page)

### 원본 텍스트

```
Position Representation Vectors
• Option 2:
• Learned absolute position representations; Let all 𝑝𝑖be learnable parameters!
• Learn a matrix 𝑝∈ℝ𝑑× 𝑛, and let each 𝑝𝑖be a column of that matrix!
• Pros: 
• Flexibility: each position gets to be learned to fit the data
• Cons:
• Definitely can’t extrapolate to indices outside 1, …, n
• (like word embeddings)
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762)
```

### 한국어 요약 결과

웹 사이트는 귀하가 웹 사이트를 탐색하는 동안 귀하의 경험을 향상시키기 위해 쿠키를 사용하는데 이 쿠키들 중에서 필요에 따라 분류 된 쿠키는 웹 사이트의 기본적인 기능을 수행하는 데 필수적이므로 브라우저에 저장되며 또한 웹 사이트가 사용 방식을 분석하고 이해하는 데 도움이되는 제 3 자 쿠키를 사용한다. 이러한 쿠키를 거부 할 수도 있다. 그러나 이러한 쿠키 중 일부를 선택 해제하면 검색 환경에 영향을 미칠 수 있다. 이러한 쿠키들을 선택 해제 하면 검색 환경에 영향 미칠 수도 있다. 이런 쿠키들 중 일부 선택 해제된 쿠키와 제 3자 쿠키를 사용할 수 있다. 또한 이러한 쿠키들은 웹 사이

### (옵션) 영어 번역 요약

The web site uses cookies to improve your experience while you are browsing for web sites, which are required to perform the basic features of web sites, so that cookies are stored in the browser, as well as using my third cookie, which helps the site to analyze and understand how they are used.

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 6 — page_66 (page)

### 원본 텍스트

```
Limitations of Self-Attention (2)
• 2nd challenge: there is no non-linearities. It’s all just weighted averages. 
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762) 
query
q
keys
k1
values
v1
k2
v2
k3
v3
k4
v4
k5
v5
output
෍
Even stacking multiple layers 
cannot introduce any non-linearity 
because it’s still a summation of 
value vectors
output
෍
```

### 한국어 요약 결과

약관 능력 그들은 악기 인기 요리 투명 하나와 함께 탭    d  ph   . 혼다 양식 bombard.crminebard   crmina   p   혼다 양 양 양   maxi  .혼다 양  mbard는   백기 인기 인기 요리 불투명 하나와 탭으로 탭,   P   D   T   N   로  약관, 약관,  약사 능력 그들은   선기 인기  투명 하나과 함께   약관

### (옵션) 영어 번역 요약

Indecencies, they have a tab dph.comp with an instrument-like transparency and a bonda-like bambard. crminada-like maxi. mbard is a tab with a white-fledged dish, PTN with a tab, an apothecary, an apothecary, and an apothecary.

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 7 — page_67 (page)

### 원본 텍스트

```
Adding nonlinearities in self-attention
• Note that there are no element-wise 
nonlinearities in self-attention; 
stacking more self-attention layers just 
re-averages value vectors
• Easy fix: add a feed-forward network to 
post-process each output vector 
• 𝑚𝑖= 𝑀𝐿𝑃𝑜𝑢𝑡𝑝𝑢𝑡𝑖
•
= 𝑊2 ∗𝑅𝑒𝐿𝑈𝑊1 𝑜𝑢𝑡𝑝𝑢𝑡𝑖+ 𝑏1 + 𝑏2
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762)
```

### 한국어 요약 결과

웹 사이트는 귀하가 웹 사이트를 탐색하는 동안 귀하의 경험을 향상시키기 위해 쿠키를 사용하는데 이 쿠키들 중에서 필요에 따라 분류 된 쿠키는 웹 사이트의 기본적인 기능을 수행하는 데 필수적이므로 브라우저에 저장되며 또한 웹 사이트가 사용 방식을 분석하고 이해하는 데 도움이되는 제 3 자 쿠키를 사용한다. 이러한 쿠키를 거부 할 수도 있다. 그러나 이러한 쿠키 중 일부를 선택 해제하면 검색 환경에 영향을 미칠 수 있다. 이러한 쿠키들을 선택 해제 하면 검색 환경에 영향 미칠 수도 있다. 이런 쿠키들 중 일부 선택 해제된 쿠키와 제 3자 쿠키를 사용할 수 있다. 또한 이러한 쿠키들은 웹 사이

### (옵션) 영어 번역 요약

The web site uses cookies to improve your experience while you are browsing for web sites, which are required to perform the basic features of web sites, so that cookies are stored in the browser, as well as using my third cookie, which helps the site to analyze and understand how they are used.

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 8 — page_68 (page)

### 원본 텍스트

```
Limitations of Self-Attention (3)
• 3rd challenge: need to ensure we don’t “look at the future” when predicting a 
sequence
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762)
```

### 한국어 요약 결과

는 코펜하겐의 마음과 함께 1  작은 능력 ankins universal 9001을 화나게 하는 1   작은    크   2  작은 능력을 ankiver   c   0   k   이   오   )   전   서   .   /   관계자는  ,   ,   과학   문   후   ”   와   로   )는   (   '   }   작가는   ·

### (옵션) 영어 번역 요약

I am standing. / Relationships, after science. ”

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 9 — page_69 (page)

### 원본 텍스트

```
Masking the Future in Self-Attention
• To use self-attention in decoders, we 
need to ensure we can’t peek at the 
future.
• At every timestep, we could change 
the set of keys and queries to 
include only past words. 
(inefficient!)
• To enable parallelization, we mask 
out attention to future words by 
setting attention scores to −∞.
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762)
```

### 한국어 요약 결과

화난 이제 화난 한시 컴퓨터    관계자는  ️   보내   감사  해가지고   해   모두   이렇게 화난   이   왜   다들   더 화난 여자   파렴   마치   화난 한   여기 화난 아이 컴퓨터  이렇게   
   이들은  모두 화난 어이   사귀   공을   본인의   다르게   후️  해와   ""   이기   되게   자신이   너무   잘못   문️ ️

### (옵션) 영어 번역 요약

Now, angry and angry, one-time computer agents have all come to appreciate why everyone's so angry at a more angry woman like an angry child computer like this one who's so angry that they're all saying, "I'm so sorry that you're so mad at me that you're so mad at me that you're so mad at me."

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 10 — page_70 (page)

### 원본 텍스트

```
Self-Attention as a New Building Block
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762) 
• Barriers and solutions:
• 1. Doesn’t have an inherent notion of order
• -> Add position representations to the inputs
• 2. No nonlinearities for deep learning magic. It’s all just weighted averages
• -> Easy fix: apply the same feedforward network to each self-attention output
• 3. Need to ensure we don’t “look at the future” when predicting a sequence
• -> Mask out the future by artificially setting attention weights to 0!
```

### 한국어 요약 결과

탱크 초보자 그래서 포춘 아키하바라 명예 1926 능력、 ING 끝、 능력과 함께 。。。.” 적절한 역사 、에서 적절한 역사 를 적시도록 그래서 정렬 workter 때문에 당신의 1.5 산업 맥카 경치가 좋은 양식 개최 드라이브를 나타냅니다.

### (옵션) 영어 번역 요약

So fortuney Akihabara, honor 1926, with the end of the InG." So you line up your 1.5-induced McCarthy view for a good form drive because of the proper history process.

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

## Unit 11 — page_71 (page)

### 원본 텍스트

```
“Transformer”
https://web.stanford.edu/class/cs224n/
Attention Is All You Need (https://arxiv.org/pdf/1706.03762) 
• Self-attention:
• The basis of the method.
• Position representations:
• Specify the sequence order, since self-attention is 
an unordered function of its inputs.
• Nonlinearities:
• At the output of the self-attention block
• Frequently implemented as a simple feed-forward 
network.
• Masking:
• In order to parallelize operations while not looking 
at the future.
• Keeps information about the future from “leaking” to 
the past.
```

### 한국어 요약 결과

탱크는 너무 초심자이기 때문에 Fortune Akihabara 명예 1926 능력은 하나의기도를 화나게 했고 능력 、 능 、 탄력성 、 하나의기도 、 잘 . 잘 . 능력  、    능 능력은 、 탄성   잘 .   능력이 、 능력을 、 화나게 하였다.   
탱크는  탱크의 초심자가이기 때문에   AKihibara 명장은 하나의기도의 화나게 했으며   "탱크 、 "   you Hond

### (옵션) 영어 번역 요약

The tank was so super-insult that the honor 1926 power of Fortune Akihabara upset one prayer, and the power of the wind went well.

### 비고

- ※ 원문이 비한국어로 추정되어 `en→ko` 번역 후 요약을 수행했습니다.


---

