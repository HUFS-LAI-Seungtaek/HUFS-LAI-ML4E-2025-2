# BonCahier AI Summary — NLP_Lec3&4_NLP_TM_slides.pdf

- 생성 시각: 2025-12-06T03:29:43
- 원본 파일 경로: /content/NLP_Lec3&4_NLP_TM_slides.pdf
- 요약 모델: /content/drive/MyDrive/boncahier/models/kobart_ko_news
- 처리 대상 페이지/슬라이드 범위: 16-30 (총 15개)
- 전체 페이지/슬라이드 수: 120

---

## Unit 1 — page_16 (page)

### 원본 텍스트

```
What is TM?
Text Data Mining
Used to derive qualitative insights from unstructured data
A method for drawing out content based on meaning
and context from a large body of text
It uses NLP, allowing machines:
To understand the human language 
To process it automatically
Combining notions of statistics, linguistics, and machine 
learning to create models that learn from training data and 
predict results on new information based on their previous 
experience
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
16
```

### 한국어 요약 결과

'To process it automatically
A method for drawing out create models that learn from training data and 
predict results on new information based on their previous and machines
experience
Nov. 25 & Dec. 01, 2025
Introduction to L


---

## Unit 2 — page_17 (page)

### 원본 텍스트

```
What is TM? (cont’d)
A process of deriving meaningful information from 
natural language text
The process of transforming unstructured text into structured
format for easy analysis 
To identify meaningful patterns and new insights
The use of computational methods and techniques to extract 
high-quality information from text 
A process of exploratory data analysis that leads to 
heretofore unknown information or to answer for questions 
for which the answer is not currently known
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
17
```

### 한국어 요약 결과

'T process of transforming unstructured text into  leads to the answer for questions,   asy analysis,  heretofore use of unknown inform, and techniques to  setract,  sov. 25 & Dec. 01, 2025
Introduction to Langu


---

## Unit 3 — page_18 (page)

### 원본 텍스트

```
What is TM? (cont’d)
An AI technology
Using NLP to transform the free (unstructured) text in 
documents and databases into normalized, structured data 
suitable for analysis or to drive machine learning (ML) 
algorithms
The process of examining large collections of documents 
To discover new information 
To help answer specific research questions
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
18
```

### 한국어 요약 결과

Anov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025, 1825
1825, 1925, I. 25. 25, Dec, 2025    discover new information,   help answer specific research questions,  dired data,  Into dismithms, and dilection to


---

## Unit 4 — page_19 (page)

### 원본 텍스트

```
What is TM? (cont’d)
Basics
Document
Anything which one may search for, which contains information
in different media (text, image, …) 
– The focus of the class: text
Text documents 
Description in a natural language 
Human vs. computer understanding 
Reading the text and understanding the meaning 
A computer cannot (yet) understand meaning as a human being, 
but can quickly process symbols (strings, words, etc.)
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
19
```

### 한국어 요약 결과

Inroduction to Language Technology 2025
Introdurution to Lyuage Pech Nov. 25 & Dec. 01, 2025, Intoduduage, 1925, 2025의I. 25, Dec, 19 25, 25 and Dec . 1925
"A computer cannot (yet) understand meaning as a human being, but can quic


---

## Unit 5 — page_20 (page)

### 원본 텍스트

```
What is TM? (cont’d)
Basics (cont’d)
Document parsing
Identify document format (text, Word, pdf, …)
Identify different text parts (title, text body, …)
– Note: often separate index for different parts
Go through a text, and recognize the words
– Tokenization
– The elements recognized = tokens
– Statistics for weighting
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
20
```

### 한국어 요약 결과

Noroduction to Language Technology 2025
Tokenization, The elements recognized = tokens, Statistics for weighting, Nov. 25 & Dec. 01, 2025, 1925
Introdurule to LyuageTech Nologi 2025의 2025


---

## Unit 6 — page_21 (page)

### 원본 텍스트

```
What is TM? (cont’d)
TM Process
In TM applications, a data scientist or other analyst:
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
21
```

### 한국어 요약 결과

Inroduction to Language Technology 2025, process, a data scientist or other analyst:    Dec. 01, 2025
Intro udu   plications,   daa s cientica or  others.   . . .  .  di  dota  . chnolologi 2025 .   I. 25 & Dec


---

## Unit 7 — page_22 (page)

### 원본 텍스트

```
What is TM? (cont’d)
Key components of TM
Data Collection
Gathering text data from various sources such as websites, 
social media, emails, and internal documents
Preprocessing
Cleaning and preparing the text data by removing noise, 
normalizing text, and tokenizing
Transformation
Converting text into a structured format using techniques like 
vectorization
Analysis
Applying NLP, machine learning, and statistical methods to 
identify patterns and extract insights
Visualization
Presenting the findings in an easily understandable format
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
22
```

### 한국어 요약 결과

Nopplying NLP, machine learning, and statistical methods to identify patterns and extract insights, and tokenizing,   presenting the findings in an easily understandable format,  preparing techniques like,  I. 25 & Dec. 01, 2025


---

## Unit 8 — page_23 (page)

### 원본 텍스트

```
What is TM? (cont’d)
Process of TM
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
23
```

### 한국어 요약 결과

Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025 is TM? (cont’d)
Process of TM,   Cont'd,  TM
Nov, 25. 25, Dec, 0 1, 2025,  Cd, 2025 .    . TM . . .  .troaduction,  Decd, TM  . . Tm,  . Contsess of


---

## Unit 9 — page_24 (page)

### 원본 텍스트

```
What is TM? (cont’d)
Text Mining vs. Data Mining
Text Mining
Dealing with unstructured textual data
– Free-form text
» No pre-defined or organized in any way
Requiring an extra step 
– The unstructured data has to be organized and structured in a 
way that allows the data modeling and analytics to occur
Concerned with the detection of patterns in NL texts
Data Mining
Handling structured (highly formatted) data
Combining disciplines including statistics, AI and machine 
learning to apply directly to structured data
Concerned with the detection of patterns in database
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
24
```

### 한국어 요약 결과

'Tith unstructured data modeling and analytics to occur
Concerned with the detection of patterns in NL texts
Data Mining disciplines including statistics, AI and machine and apply directly    patted daa

'Introd


---

## Unit 10 — page_25 (page)

### 원본 텍스트

```
What is TM? (cont’d)
Text Mining vs. Data Mining (cont’d)
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
25
Text Mining
Data Mining
Concept
A process required to turn 
unstructured text document into 
valuable structured information
A spectrum of  different 
approaches, which searches from 
patterns and relationships of data
Retrieval of 
Data 
With standard text mining 
methods discovers a lexical & 
syntactic features in the text
With standard data mining 
techniques reveals business 
patterns in numerical data
Type of Data
Discovery of  text from 
unstructured data which are 
heterogeneous, more diverse
Discovery of  knowledge from 
structured data, which are 
homogeneous and easy to access
Complexity 
Counting several intermediary 
linguistic stages of  analysis before 
it can enrich content
Not requiring any deep 
understanding of  the context
```

### 한국어 요약 결과

A pproaches, which searches from a lexical and easy to access
Type of Data
With standard text mining 
methods discovers letures in the ttext
syntactic features reveals business
patterns in numerical data,  speose a se


---

## Unit 11 — page_26 (page)

### 원본 텍스트

```
Why TM?
TM has become more practical thanks to
The development of big data platforms 
Deep learning algorithms that can analyze massive sets of 
unstructured data
Mining and analyzing text helps organizations 
Find potentially valuable business insights in corporate 
documents, customer emails, call center logs, verbatim survey 
comments, social media posts, medical records and other 
sources of text-based data
TM capabilities
Increasingly incorporated into AI chatbots and virtual agents 
that provide automated responses to customers as part of 
their marketing, sales and customer service operations
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
26
```

### 한국어 요약 결과

Inroduction to Language Technology 2025
'to AI chatbots and virtual agents, as part of automated responses to customers and logs, verbatim survey, social media posts, medical records and other service operations, geir marketing


---

## Unit 12 — page_27 (page)

### 원본 텍스트

```
Why TM? (cont’d)
There are many examples of text-based documents (all 
in ‘electronic’ format…)
e-mails, books, news articles, blog posts, corporate Web 
pages, customer surveys, résumés, medical records, technical 
papers, incident reports, messages/posts on social networking 
and social media sites, and more… 
Not enough time or patience to read
Can we extract the most vital kernels of information…
So, we wish to find a way to gain knowledge (in 
summarised form) from all that text, without reading 
or examining them fully first…!
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
27
```

### 한국어 요약 결과

''ithout reading them fully first...!
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025, 2725
2727
27o, we wish to find a way to gain knowledge (in 
summarised form) from them (in that text, all that seading a wirt, w


---

## Unit 13 — page_28 (page)

### 원본 텍스트

```
Why TM? (cont’d)
80% ~ 90% of the data is unstructured 
Based on the volume predicted by a study claiming that data 
will experience 181.93% growth from 2020 to 2025
Text files: word files, spreadsheets, presentations, logs
E-mails: the body of the message
Data from social media platforms
Mobile data: messages, location, chats
pictures, videos, audio, weather data, satellite images, sensor 
data
Information under unstructured data can be referred to 
as content
The content doesn't follow a predefined schema or data model
Making it more challenging to analyze data
Information intensive business processes demand knowledge
discovery rather than simple document retrieval 
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
28
```

### 한국어 요약 결과

Information intensive business processes demand knowledge data
Introduction to Language Technology 2025
28ov. 25 & Dec. 01, 2025, 25 & Entruage, 25, 2025,
Itroaduction under unstructured daya can be referred to as content does


---

## Unit 14 — page_29 (page)

### 원본 텍스트

```
Motivations for TM
Information and text documents
A recent study indicated that 80% of a company's 
information is contained in text documents
e.g., emails, memos, customer correspondence, and reports
The ability to distil this untapped source of information 
Able to provide substantial competitive advantages for a 
company to succeed in the era of a knowledge-based economy
TM overcomes the limitation of database
Database limits itself to storage of less information
TM extracts relevant information & relationships from 
natural documents
The documents which are unstructured or semi-structured
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
29
```

### 한국어 요약 결과

Imroduction to Language Technology 2025
A recent study indicated that 80% of a company's in text documents, and relationships from the semi-structured economy
TM extracts relevant itself to storage of less information, re


---

## Unit 15 — page_30 (page)

### 원본 텍스트

```
Goals of TM
Understanding the following:
The basic ideas of data mining
How computer scientists & text miners approach texts
The overall goal
Essentially to turn text into data for analysis, via 
application of NLP
Nov. 25 & Dec. 01, 2025
Introduction to Language Technology 2025
30
```

### 한국어 요약 결과

plication of NLP
Introduction to Language Technology 2025
The overall goals of TM
Essentially to turn text into data for analysis, via, applysi, NLA
Nov. 25 & Dec. 01, 2025, I. 25, Dec, 2025 , . . . 25, dec. dec, 01,


---

