# BonCahier AI Summary — PythonReview.pdf

- 생성 시각: 2025-12-06T03:41:54
- 원본 파일 경로: /content/PythonReview.pdf
- 요약 모델: /content/drive/MyDrive/boncahier/models/kobart_ko_news
- 처리 대상 페이지/슬라이드 범위: 2-55 (총 54개)
- 전체 페이지/슬라이드 수: 56

---

## Unit 1 — page_2 (page)

### 원본 텍스트

```
§!Basic!math!operations!work!as!one!would!expect!from!a!fancy!
calculator,!including!using!parentheses!to!explicitly!indicate!grouping.
§!To!get!a!float,!ensure!that!a!decimal!is!specified,!as!in 2.0,!and 2. will!
suffice!for!this.!Bare!digits!like 11 are!int.
§!In!Python!3,!ints get!coaxed!into!floats!where!you!would!expect,!as!
in 2/3 returning 0.66666666667.
§!Exponentiation!is!with **,!as!in 2**3.!Take!care!not!to!use ^,!as!it!is!
something!else!(something!obscure:!bitwise!exclusive!'or＇).
§!Assignment!statements!are!like x!=!2.!This!is!not!saying x is!equal!to 2,!
but!rather!setting!the!value!of!the!variable x to 2.
§!For!equality,!use ==,!as!in (2!+!2)!==!(1!+!3).!This!will!return True.
§!For!not-equal,!use !=.
§!The!inequality!operators!are <, >, <=, >=.
The$basics$of$numerical$types$and$strings
Numbers(and(basic(math
```

### 한국어 요약 결과

' 'ith!' ! ! ' ' '    ' ' . ' ' " " "   "  " " '  '  " ' '!  ! "  '! 'i! ' !! ' . !this.!  'In!Python!,! 'o!' .  'tho!  .   . 'ike!spect! x  returning 0.666666667.!  "! ' I! 'I! '.! '


---

## Unit 2 — page_3 (page)

### 원본 텍스트

```
§!How!do!you!specify!a!complex!expression!like 2!+!4!- 1 as!an!
exponent?
§!What!do / and // do,!and!how!do!they!differ?
§!How!can % (modulo)!be!used!to!test!whether!a!number!is!even?
§!Python!has!a!keyword!operator is that!we!will!cover!later.!Can!you!
find!a!case!where == and is are!the!same!and!one!where!they!are!
different?
The$basics$of$numerical$types$and$strings
Basic(math(exercises
```

### 한국어 요약 결과

Basic(math(exercisessees$of$numerical$types$and$strings
Bhat!we!where == and is are!the!same!and!one!    Basy!different?
The$basics.ofmof.maath, math 'exergings,Basy(exhises$af$oth(


---

## Unit 3 — page_4 (page)

### 원본 텍스트

```
§ Strings!can!be!specified!using!single!quotes,!double!quotes,!or!a!
sequence!of!three!single!or!double!quotes!(triple!quotes).
§ Use!single!quotes!(or!triple!quotes)!if!your!string!contains!double!
quotes,!and!use!double!quotes!(or!triple)!if!your!string!contains!single!
quotes.
§ Triple!quotes!can!include!newlines.
§ Digits!inside!strings!are!strings.!That!is,!in 's9', '9' is!a!str,!not!an!int.
§ To!turn!a!number!string,!use str(),!as!in str(11),!which!returns '11'.
The$basics$of$numerical$types$and$strings
str
```

### 한국어 요약 결과

' 'i!specified!single!'  ' ' '  '   ' That!is,! ' ' To!turn!' ' ' .    Co!not! '  Bo!  ' side!  is! ' 9'   Ao!mof$basics$of.   " ' ' s9', ' '9'  I! ' . ' is, ' ' I!' .  ' I '  I,!  .


---

## Unit 4 — page_5 (page)

### 원본 텍스트

```
§ x[0] picks!out!the!first!character!of x.
§ x[0:!2] picks!out!characters!0!and!1!(first!and!second)!of x.
§ So,!note:!indexed!ranges!include!the!first!index!named!and!everything!
up!to,!but!not!including,!the!second!index.
§ If!you!leave!off!the!first!index!in!a!range,!then!it!is!assumed!to!go!to!
the!beginning. x[!:!2] is!the!same!as x[0:!2].
§ If!you!leave!off!the!second!index!in!a!range,!then!it!is!assumed!to!go!
to!the!end: x[1:!].
§ If!the!second!index!is!larger!than!the!final!index,!then!the!returned!
subspan goes!all!the!way!to!the!end!of!the!string.
• Thus,!if!we!did x!=!"abc",!then x[1:!] and x[1:!3] are!the!the!
same.
• Notice!that x[3] throws!an!exception,!though.
§ x[-1] picks!out!the!final!element!of x,!and x[-2] picks!out!the!second!
to!last!element!(and!so!forth).
The$basics$of$numerical$types$and$strings
Indexing
```

### 한국어 요약 결과

' '!the!'ho!   second!  ' ' 'i!'   so! ' 'hus!  If! is! ith! seo!d! 'the'! x[1] are!  same,   '   " "i! if! we!ther! as! on!  .   . ' '  s[seh! om[secluding,  'ii!i!th


---

## Unit 5 — page_6 (page)

### 원본 텍스트

```
§ We've%seen%that + is%flexible%with%regard%to%the%types%it%can%combine%with.%For%
example, 1%+%2 returns 3,%but "1"%+%"2" returns "12".
• What%happens%if%you%try%to%use + to%combine%things%with%different%types?
§ Same%question%as%the%above,%but%not%with * as%the%operator.
§ What%happens%if%you%apply%the%built-in%function int to%a bool?
(Try%it%with float too!)
§ You've%probably%noticed%that%the%types%all%have%associated%built-
ins: int, float, str, bool.
• What%does bool do%if%you%apply%it%to%the%string "a"?
• What%about%the%string "" (the%empty%string)?
§ Suppose%you%define x%=%"abc".
• What%does x[0:1] return?
• What%about x[0:0]?
• See%if%you%can%guess%correctly%before%trying%the%code.
§ Suppose%you%have%a%string%with%an%odd%number%of%characters%in%it,%but%you%don't%
know%its%precise%length.%Write%code%that%will%return%the%character%that%is%at%the%
precise%middle%of%the%string.
The$basics$of$numerical$types$and$strings
Exploratory(exercises
```

### 한국어 요약 결과

Sample, 1%+%2 returns,%to%but "1"%"2" regard%types, "12"., What%happens%you%probably%the%dose%thool, and See%pose,  set,  same%., Same.,  ", ", as%above%associated%built-


---

## Unit 6 — page_7 (page)

### 원본 텍스트

```
§ Concatenation:%use +.%Thus s%+%s returns%the%concatenation%of s with%itself.
• This%is%a%common%pattern%in%Python:%the + operator%is%addition%if%the%
arguments%are%numerical,%and%it%is%concatenation%if%the%arguments%are%str.
§ x.upper() returns%a%version%of x with%all%letters%mapped%to%uppercase.%See%
also x.lower(), x.capitalize(), x.title().
§ x.replace("b",%"X") returns%a%new%string%in%which%all "b" characters%in x have%been%
replaced%with "X".
§ x.replace("b",%"") returns%a%new%string%in%which%all "b" characters%in x have%been%
replaced%with%the%empty%string,%which%basically%deletes%every b.
§ x.strip() removes%all%whitespace%at%both%edges%of x.%The%
variants rstrip and lstrip target%only%right%and%left%edges,%respectively.%Only%the%edges%
are%targeted.
§ x.strip('b') removes%all%tokens%of 'b' at%the%edges,%if%there%are%any.
§ If s is%a str,%then s.split() will%split s on%whitespace.%This%deletes%the%whitespace%
itself.
§ split can%also%take%arguments: "a,b,c".split(",") will%split%on%the%comma,%
returning ['a',%'b',%'c’].
§ To%delete%things%from%inside%a%string,%use replace with%the%empty%string,%as%above.
The$basics$of$numerical$types$and$strings
String(methods(1
```

### 한국어 요약 결과

Con%common%pattern%인%concatenation%인 returns%a%deletes%been% removes%all%which%pharacters%asically%bave%andges%of x.strip, replaced%.%The%
" lefts "b" regith "b,% "b.%. reletse%


---

## Unit 7 — page_8 (page)

### 원본 텍스트

```
§Strings%are%not mutable -- they%can't%be%changed.%So%all%of%the%above%return%new%
strings,%leaving%the%original%untouched.
• The%only%way%to%change%the%value%of%a%string%variable%is%via%assignment: x%=%
x.upper().
§ There%are%many,%many%string%methods,%so%it's%good%to%check%the%documentation%to%
see%if%there%is%a%method%that%does%what%you%want%before%you%write%your%own
§ The join method%on%strings%is%a%converse%of split:%given%a%string,%it%will%join%its%list%
argument%on%that%string.%Try%these%out%to%see%what's%happening:
• "_".join(['a',%'b',%'c'])%"%".join(['a',%'b',%'c'])%"%tiny%".join(['the',%'puppy’])
• I%personally%find%that%I%often%mistakenly%think%of join as%a list method,%rather%
than%a str method,%and%so%I%write x.join("_") where x is%a list of str.%Python%
doesn't%do%things%that%way!
§ The format method%for str is%very%powerful.%The%basics:
• "{}%is%my%name".format("chris")%"{}%plus%{}%is%{}".format(2,%3,%2+3)
§ Methods%can%be%chained%together%to%create%powerful%one-liners.%For%example:
• x%=%"***the%dog***"%x.strip("*").split()%This%returns ['the',%'dog’].
• Breaking%it%down, x.strip("*") is%a str,%so%all str methods%work%for%it.
§ We%observed%that%reversing%them%fails: x.split().strip("*").%This%is%because x.split() is%
a%list,%whereas strip is%a str method.
The$basics$of$numerical$types$and$strings
String(methods(2
```

### 한국어 요약 결과

%%to%change%the%value%of%a%string%variable%assignment: x% (x.upper().
§ The join method%on%sto%before%you%thosee%ahat%does%a,%write%way%. and theyseo%. of%go% ", and the jose%.%. ", ",


---

## Unit 8 — page_9 (page)

### 원본 텍스트

```
p!=!"the!quick!brown!fox!jumps!over!the!lazy!dog"
§ Return!the!first 'the’
§ Return 'lazy' using!negative!indexing.
§ Change!it!to!title!case
§ Remove!the!final g.
§ Now!put!that g back.
§ Remove!all!occurrences!of quick.
The$basics$of$numerical$types$and$strings
Str(exercises
```

### 한국어 요약 결과

Str(exercises)가 ' '  using!negative!indexing, Change!it!to!title!case, Now!put!the!that g back, Remove!all!occurrences!of quick,  " " "
Str(str,    "  "
'   (exerceises$of$numerical$types


---

## Unit 9 — page_10 (page)

### 원본 텍스트

```
§ Lists!have!many!shared!properties!with!strings.!For!many!purposes!in!
Python,!a!string!is!a!list!of!characters.
§!Lists!are!done!with!square!brackets,!with!the!elements!separated!by!
commas: [1,!2,!3] is!a!list,!as!is [1].
§!Lists!can!contain!any!Python!object,!including!other!lists: [[1,!2],!4].
§!List!can!contain!mixtures!of!different!kinds!of!objects: [[1,!2],!4,!False,!
7,!2.0].
§!To!add!something!to!the!end!of!a!list,!use!the append method!--
given x!=![1,!2,!3], x.append(0) adds 0 to!the!end.
§!Using append actually!changes x!!Lists!are!mutable!
§!If!you!want!to!avoid!changing x,!you!can!use +,!as!in x!+![0].!This!
returns!a!new!list,!leaving x unchanged.
§!Notice!the!intuitive!use!of + there.!For!numerical!types,!it!means!
addition.!For!str!and!list,!it!means!concatenation.
The$basics$of$lists,$built-ins,$for-loops,$conditionals,$
and$function$definitions
list(1
```

### 한국어 요약 결과

Lists!mixtures!mo!different!of!ho!the!meth!  ' ' ',! ', ' '   is!   chared!  .   List! ' 'ith!'   "  ! ! 'here!  
!  " "  'i! '  " ' ' "  ",! x.append actually!  method!  diff!


---

## Unit 10 — page_11 (page)

### 원본 텍스트

```
§ What!does [1]!*!5 do,!then?!What!about [1,!3]!*!5?
§!The!method insert can!be!used!to!add!things!to!any!place!in!a!list.!The!
pattern!is x.insert(index,!value),!where index is!the!position!you!want!
the!new!element!to!occupy:
•!x!=![1,!2,!3]
•!x.insert(1,!"a") changes x to [1,!'a',!2,!3]
•!x.insert(len(x),!"a") is!the!same!as x.append("a")
§!x.index(2) is!just!like x.find(2),!but!it!raises!an!exception!of!there!is!
no 2 in x.
§!x.sort() will!sort x in!place,!using!whatever!logic!Python!has!for!sorting!
objects!inside x.!This!will!fail!if!the!objects!are!of!different!types.
§!There!are!many!other!list!methods
The$basics$of$lists,$built-ins,$for-loops,$conditionals,$
and$function$definitions
list(2
```

### 한국어 요약 결과

' 'ike!me!sposition!'ho!do!tho!'does! 'here!' ' ' '   is!   '  do! 'ith!'   changes!  ' 'hange!  .   " "  "   ('a,! ' ' "  s.do '  ( ' 'I,   I,  ' " " " '  " ' ' .  'his! will!fail!


---

## Unit 11 — page_12 (page)

### 원본 텍스트

```
§ What!does [1]!*!5 do,!then?!What!about [1,!3]!*!5?
§!The!method insert can!be!used!to!add!things!to!any!place!in!a!list.!The!
pattern!is x.insert(index,!value),!where index is!the!position!you!want!
the!new!element!to!occupy:
•!x!=![1,!2,!3]
•!x.insert(1,!"a") changes x to [1,!'a',!2,!3]
•!x.insert(len(x),!"a") is!the!same!as x.append("a")
§!x.index(2) is!just!like x.find(2),!but!it!raises!an!exception!of!there!is!
no 2 in x.
§!x.sort() will!sort x in!place,!using!whatever!logic!Python!has!for!sorting!
objects!inside x.!This!will!fail!if!the!objects!are!of!different!types.
§!There!are!many!other!list!methods
The$basics$of$lists,$built-ins,$for-loops,$conditionals,$
and$function$definitions
list(2
```

### 한국어 요약 결과

' 'ike!me!sposition!'ho!do!tho!'does! 'here!' ' ' '   is!   '  do! 'ith!'   changes!  ' 'hange!  .   " "  "   ('a,! ' ' "  s.do '  ( ' 'I,   I,  ' " " " '  " ' ' .  'his! will!fail!


---

## Unit 12 — page_13 (page)

### 원본 텍스트

```
§ len is!different!than!the!methods!above:!it!is!a!built-in!function!that!
can!operate!on!many!expressions.
• Thus,!to!get!the!length!in!characters!of!a!string s,!use len(s)
§ Similarly,!to!convert!a!string!to!an!int,!use int("1").!For!a!float,!
use float("1").
§ Concatenation:!use +.!Thus s!+!s returns!the!concatenation!of s with!
itself.!This!is!a!common!pattern!in!Python:!the + operator!is!addition!if!
the!arguments!are!numerical,!it!is!concatenation!if!the!arguments!are!
str,!and!it!creates!a!new!list!if!given!lists!as!arguments.
§ You!can!also!do "x"!*!5,!which!return "xxxxx".
The$basics$of$lists,$built-ins,$for-loops,$conditionals,$
and$function$definitions
Some(built-in(functions
```

### 한국어 요약 결과

Thus,!to!get!the!different!  ' 'ith!' ' ' '    " "  "   ('   '  Bhis!  !do! ' 'definitions,  Some(built-ins, "function some ' '
Some,   Builguments, ' ' "  Bo!  I!  .  ' " " " '  "
  'the


---

## Unit 13 — page_14 (page)

### 원본 텍스트

```
§ Iterating!over!a list:
• for!x!in![1,!2,!3]:
print(x)!
§ Iterating!over!a str:
• for!x!in!"abc":
print(x)
The$basics$of$lists,$built-ins,$for-loops,$conditionals,$
and$function$definitions
for-loops
```

### 한국어 요약 결과

hebasics$of$lists,$built-ins,moffor-loops,   conditionals,and$function$definitions,formation, forloop s,  "forfunction.for"s
for    print(x) " "   "  " " " (andfunctions, forffunction s,$for "loop,  for lo


---

## Unit 14 — page_15 (page)

### 원본 텍스트

```
§ Lone if clause:
• x%=%3
if%x%>%2:
print("{}%is%greater%than%2".format(x))%
§ Adding%an else clause:
• if%x%>%2:
print("{}%is%greater%than%2".format(x))
else:
print("{}%is%not%greater%than%2".format(x))%
§ Adding%an elif clause:
• if%x%>%2:
print("{}%is%greater%than%2".format(x))
elif x%==%2:
print("{}%equals%2".format(x))
else:
print("{}%is%not%greater%than%2".format(x))%
§ There%can%be%any%number%of elif statements.
§ The%final else is%optional,%but%it%must%occur%at%the%end%of%the%conditional%block.
The$basics$of$lists,$built-ins,$for-loops,$conditionals,$
and$function$definitions
Conditionals
```

### 한국어 요약 결과

Adding%an else is%print("{}%is%greater%than%2".format(x)%of elif statements, § The%final i%fitional,%Block.The$basics$of$lists,$function$definitions,and$built-ins$for-loops, and, if%_%.


---

## Unit 15 — page_16 (page)

### 원본 텍스트

```
§ Positivity(testing:
• def(is_positive(x):
if(x(>(0:
return(True
else:
return(False
• Note:(because x(>(0 returns True or False according(to(the(same(
logic,(the(entire(body(of(this(can(be(simplified(to x(>(0.(The(above(
shows(off(more(of(the(possibilities(for(function(formatting,(though.
§ Consider(rewriting(it(as(a(one-liner(using sum.
• def(mean(vals):
total(=(0
length(=(len(vals)
for(x(in(vals:
total(=(total(+(x
mu(=(total(/(length
return(mu
The$basics$of$lists,$built-ins,$for-loops,$conditionals,$
and$function$definitions
Function(definitions
```

### 한국어 요약 결과

Note because x(>(0 returns True or False according, the(same)
the same): def(megitive(of(the, simplified, shows,   ethotal(+(mu
total))):    sote(off(more, a(one-liner(using sum,


---

## Unit 16 — page_17 (page)

### 원본 텍스트

```
§ Tuples(are(defined(with(parentheses: (1,(2,(3),(for(example.
• In(essence,(you(can(think(of(a tuple as(a list that(is(not(mutable.
• Thus,(indexing(works(as(with list objects.
§ But(assignment(fails:
• t(=((1,(2,(3)
t[1](=(100
• This(won't(work(because(it(would(change t.
§ If(you(know(that(you(aren't(going(to(change(your(object(at(all,(
then tuple is(probably(a(good(choice(over list.
§ The(built-in tuple() function(will(convert(its(argument(to(a tuple,(
and list() will(covert(its(argument(to list.
§ Examples:
§ x(=((1,(2,(3)
y(=(list(x)
x[1](=(100(##(Throws(an(exception.
y[1](=(100(##(Works(fine;(changes(y.
tuple(list(x))(==(x(##(True!
The$basics$of$dicts,$and$tuples
tuple
```

### 한국어 요약 결과

Thus,(indexing(works)as(with parth list objects)) But(assignment(fails, (1,(2,(3),(for(example,))) function(will(convert(its(argument(to list)) will(covert, its, _ If(won't(wou(that(you(know(thou(


---

## Unit 17 — page_18 (page)

### 원본 텍스트

```
§ Python!is!built!on dicts,!and!its dict objects!are!incredibly!powerful!
§ dict are!defined!by!curly!braces,!with!any!number!of key:!value pairs!in!
them.!Examples:
• {1:!2,!2:!3,!3:!4}
{'a':!1,!'b':!True,!'c':![9,!8,!7]}!
§ The keys are!the!items!to!left!of!the!colons.!They!can!be!any!non-
mutable!Python!object.
§!The values are!the!items!to!the!right!of!the!colons.!They!can!be!any!
Python!object.
§!Look-ups!are!done!with!the!keys,!using!the!same!syntax!as!for!
indexing!into str and list:
•!d!=!{'a':!1,!'b':!True,!'c':![9,!8,!7]}
!!d['a']!##!Returns!1!
!!d['c']!##!Returns![9,!8,!7]!
§!d[x] raises!an!exception!of x is!not!already!a!key!in d.
The$basics$of$dicts,$and$tuples
dict(1
```

### 한국어 요약 결과

' 'ith!'the!defined! 'them.!themples!  ' 'a':! ' '' ' ' 'of ' 'c' '' .    '  'tho!   "  ''  !  mutable! are!ho! '  " " "  " ' '  left!syntax!as! "   By! ! " " '  so! " 'i!  "the


---

## Unit 18 — page_19 (page)

### 원본 텍스트

```
§!Dicts are!mutable,!so!you!can!add!things!to!them!with!assignment!
statements:
•!d['new']!=!4 works!even!if 'new' is!not!already!a!key!in d.
§!Dicts map!each!key!to!exactly!one!value.
§!It!is!safest!to!assume!that dicts are!not!ordered!
§!d.keys() is!a list-like!object!containing!the!keys.!To!make!it!a!regular!
list,!use list(d.keys()).
§!d.values() is!a list-like!object!containing!the!values.!To!make!it!a!
regular!list,!use list(d.values()).
§!d.items() is!a list-like!object!containing!the!key­value!pairs!as!tuples.!
To!make!it!a!regular!list,!use list(d.items()),!which!is!a!list!of!tuples.
§!len(d) gives!the!number!of!keys!in d.
The$basics$of$dicts,$and$tuples
dict(2
```

### 한국어 요약 결과

' 'ike!' is!make!do!tho!dith! ' ' '  '    ' ' It!map!dicts!   ('diled!' '  dict!  ' To!made!mo!' so! '  .the!spalues!  .   
!d.di! items! dilego!  ( ' 'd.o!to! beys!


---

## Unit 19 — page_20 (page)

### 원본 텍스트

```
§(Iterating(over(a dict:
§(d(=({"a":(1,("b":(2,("c":(3}
((#(Prints(the(keys:
((for(x(in(d:
((((((print(x)
((#(Prints(the(keys:
((for(x(in(d.keys():
((((((print(x)
((#(Prints(the(values:
((for(x(in(d.values():
((((((print(x)
((#(Prints(the(item((key-value(pair)(tuples:
((for(x(in(d.items():
((((((print(x)
((#(Separate(access(to(key(and(value(objects(with(bonus(fancy(printing:
((for(k,(v(in(d.items():
((((((print("{}(==>({}".format(k,(v))
The$basics$of$dicts,$and$tuples
dict(3
```

### 한국어 요약 결과

'((for(the(frint))):
((a) pryting(over(a dict, )) ' ' '(fith(bonus(fancy(fey.values) '):(((e(jr.filet(x)) s) '(e' sples ') ',((jey(value(pair) pair' 'tupless() 'for


---

## Unit 20 — page_21 (page)

### 원본 텍스트

```
#(Paste(this(in:
s(=("Colorless(green(ideas”
#(Measure(the(length(of(the(str(s:
#(What(will(this(code(do?(list(s)
#(Remove(all(the(spaces(from(s:
#(Paste(this(in:(tree(=(['NP',(['D',(['the']],(['N',(['code’]]]
#(Index(into(tree(to(pull(out(the(str('the’:
#(Index(into(tree(to(pull(out(the(list(['N',(['code’]]:
#(Index(into(tree(to(pull(out(the(list(['code’]:
#(Index(into(tree(to(pull(out(the(str('code':
Review$Exercise
Exercise(1
```

### 한국어 요약 결과

Measure(the(tree)는to(pull(out 'the'the,the',(['te'' s:
'Measse(to'to,to(tupo, out(tho,tho'))':
Review$Exercise
Expercee(1Exhise 1
Mee, Index(into 'to',to pull,


---

## Unit 21 — page_22 (page)

### 원본 텍스트

```
#!Methods!can!be!stacked!if!they!have!the!right!output!values.
#!For!example,!"ABC".lower().split("b")!returns!["a",!'c"].
#!Your!task:!in!a!single!line,!map!"ABC"!to!"aDc":
#!Write!a!function!`rev`!that!reverses!its!input!string!#!using!a!`for`-loop.!
#!How!many!ways!can!you!think!of!to!implement!a!function!that,!when!
#!given!a!list!`x`,!returns!`x`!in!sorted!order,!with!all!its!#!duplicates!
removed?!#!Write!a!function!`counter`!that,!given!a!list,!returns!a!dict #!
mapping!the!unique!elements!of!that!list!to!the!number!of!times!#!they!
appear!in!the!list.!For!example,!given!#!#!vals =!["a",!"a",!"b",!"c"]!#!#!
The!function!should!return!{"a":!2,!"b":!1,!"c":!1}
Review$Exercise
Exercise(2
```

### 한국어 요약 결과

' 'ith!'!that! ' ' ',!' '! ! 'ho! ' ! " ' '! " !the!  ' ' " " "! "!  !  " "    "  " '   '! 'iiew! '' ' '  '  "! '_! ' .  'ile! "iiien! 'that,! ' " '!' !ile,!mo! " "i! '?! '!ii!?!


---

## Unit 22 — page_23 (page)

### 원본 텍스트

```
§ The(iterator range is(an(efficient(way(to(create(a(list(of(indices,(which(is(
very(common(in(the(context(of('for'-loops:
•(range(5)(##(This(is(an(iterator(-- not(quite(a(list.
•(list(range(5))(##(This(is([0,(1,(2,(3,(4].
•(##(This(will(print(out(2,(3,(and(4,(each(on(its(own(line.
((for(i in(range(2,(5):
((((((print(i)
•(##(This(will(print(out(2,(4,(6,(and(8,(each(on(its(own(line:(
((for(i in(range(2,(10,(2):
((((((print(i)
•(##(A(common(pattern(for(iterating(over(the(indices(of(a(list(`vals`:
((for(i in(range(len(vals)):
((((((##(do(something(with(`i`(
§(Since range doesn't(build(its(list,(it(is(much(faster(for(very(large(values.(Try(
these(out(in(the(ipython terminal:
•(%time(x(=(range(50000000)
•(%time(x(=(list(range(50000000))
Range,$advanced$assignments,$logical$statements,$
printing,$and$function$definitions
range
```

### 한국어 요약 결과

Thor range is(the(context(of)'for'-loops):
(for(i in(range(len(vals))) soesn't(build(its(much(faster(fith(very(large(balues))), ((((i))A(common(pattern(over(ove(oathing(oith))


---

## Unit 23 — page_24 (page)

### 원본 텍스트

```
§ Python%has%some%very%nice%conventions%for%assignment%statements:
•%x%+=%1 is%the%same%as x%=%x%+%1.
•%All%the%math%operators%support%this.
For%instance, x%*=%2, x%-=%2 x%/=%2.
•%For%strings: s%=%"abc";%s%+=%"d"
•%For%lists: x%=%[1,2,3];%x%+=%[4]
•%Another%nice%convention%is simultaneous%assignment:
x,%y%=%1,%2 assigns x the%value 1 and y the%value 2.
•%This%also%works%for%lists: x,%y%=%[1,%2]
•%And%it%even%works%with%nesting:
(x,%y),%z%=%[['a',%'b'],%'c'] sets x to 'a', y to 'b' and z to 'c＇.
§%With%this%same%convention,%one%can%swap%the%values%of%two%variables%all%at%once:
•%x%=%1
%%y%=%2
%%x,%y%=%y,%x
%%x%##%Equals%2%now.
%%y%##%Equals%1%now.
Range,$advanced$assignments,$logical$statements,$
printing,$and$function$definitions
Advanced(assignment(statements
```

### 한국어 요약 결과

%%the%math%operators%assupport%this, x,%For%strings,   %, %,%,y% assignment, %, y x% %,%2%,  %Another%also%works%for%hashof%. %, ",%A,%%%.%, %%,%%2 ashignue 1 and y the%value 2


---

## Unit 24 — page_25 (page)

### 원본 텍스트

```
§ Some(noteworthy(things(about(truth(and(falsity(in(Python:
•(1(==(True(##(True!
•(2(==(False(##(False!
•(0(==(False(##(True!
•(1(is(True(##(False!
•(0(is(False(##(False!(
§(Truth(and(falsity(on(conditionals:
•(for(x(in([None,(False,("",(0,([],((),({}]:
((((((if(x:
((((((((((print("This(code(will(not(execute")
((((((else:
((((((((((print("This(code(will(execute")
•(for(x(in(["(",(True,([1],((1,),({1:(2}]:
((((((if(x:
((((((((((print("This(code(will(execute")
((((((else:
((((((((((print("This(code(will(not(execute")
Range,$advanced$assignments,$logical$statements,$
printing,$and$function$definitions
Truth,(falsity,(and(identity
```

### 한국어 요약 결과

Some(noteworthy(things(truth(and(falsity))) ' '는 ' ', ' '(((efore, 'false ' ' 'efitionals:
'for(x:
) ',(( 'e,(e,"(("e("This(code(will "not(execute")) ",(for,("(e(frue, "(( "(


---

## Unit 25 — page_26 (page)

### 원본 텍스트

```
§ You$can$join$boolean-valued$statements$with and and or,$and$you$can$negate$them$
with not.$Bracketing$will$let$you$control$how$different$pieces$of$the$code$associate.
§ The in operator$tests$whether$the$thing$on$the$left$is$a$member$of$the$thing$on$the$
right.$It$works$with str, list, tuple,$and dict,$among$others.
• For dict,$it$tests$the$keys.
§ Some$examples$inside$a$function$definitions:
• def$valid_twitter_username(s):
return$s.startswith("@")$and$"$"$not$in$s$and$"@"$not$in$s[1:$]
• def$contains_neither_a_nor_b(s):
return$not$('a'$in$s$or$'b'$in$s)$
§ In$connection$with$the$above$section Truth,$falsity,$and$identity,$I$should$note$that$the$
behavior$of not with$respect$to$various$things$that$are$informally$true$and$false:
• not$None$##$True!
• not$0$##$True!
• not$""$##$True!
• not$[]$##$True!
• not$1$##$False!
• not$"$"$##$False!
• not$[""]$##$False!
Range,$advanced$assignments,$logical$statements,$
printing,$and$function$definitions
Logical(operators
```

### 한국어 요약 결과

Some$identity,$should$the$of not,$andof, or,$among$others. § The in operator$tests$ left,$a$let$thamples.  
 def$side$function$definitions:
return$s.startswith("   sele,  ")$and.  ", de


---

## Unit 26 — page_27 (page)

### 원본 텍스트

```
§ I've!taken print() for!granted!a!bit,!but!it's!worth!calling!out!that!it!is!a!
built-in!method,!akin!to len() and str().
§ You!can!feed!it!lists!of!objects,!and!it!will!do!its!best!to!print!them!
out.
§ Here!are!some!illustrative!examples!that!go!beyond!what!we've!seen!
so!far:
• print("a",!"b",!"c",!sep="_")
• print("a",!"b",!"c",!sep="_",!end="***")
• print("a",!"b",!"c",!sep="_",!end="\n\n")
Range,$advanced$assignments,$logical$statements,$
printing,$and$function$definitions
Advanced(printing
```

### 한국어 요약 결과

' 'i's!method!'that!'' so!sprint!'
Range,$advanced$assignments,$logical$    prinitions, Advanceed(princed,  "bile,$and,"   "Adb",!"c",!sep="_")
• prit("a",!"b, "c", "c, " " ", ", pr


---

## Unit 27 — page_28 (page)

### 원본 텍스트

```
§ We%reviewed%the%basics%of%defining%functions: def$myfunc(args):
• where args is%the%comma-separated%list%of%arguments%to%the%function.
§ As%you've%seen%already%in%a%few%places%(see print and sorted above).%functions%can%
also%have%named,%optional%arguments:
• def%exponent(x,%pow=2):
return%x**pow
• This%function exponent can%be%called%as exponent(3),%in%which%case pow is%
set%to 2 according%to%the%default.%It%can%also%be%set%to%other%values%
with exponent(x,$pow=3)
§ Whether%optional%or%not,%function%arguments%can%be%called%with%their%names%in%
Python.
• For%example, exponent(pow=3,%x=2) will%compute x**pow.
• This%helps%if%one%has%a%lot%of%arguments%and%the%order%is%hard%to%remember.
§All%named%arguments%have%to%follow%all%unnamed%ones,%and%unnamed%arguments%
are%assumed%to%be%in%the%same%order%as%they%are%in%the%function's%definition.
Range,$advanced$assignments,$logical$statements,$
printing,$and$function$definitions
Advanced(function(signatures
```

### 한국어 요약 결과

As%seen%already%a%few%places%(see print and sorted above).%functions%to%as exponent(x,%pow is% ", and def. also%be%"has%as set%as,%other% "guguments, and leturn%.   (,   " ",  ", ", deth ex


---

## Unit 28 — page_29 (page)

### 원본 텍스트

```
import!math
def!mean(vals):
return!sum(vals)!/!len(vals)
def!sd(vals,!sd_corr=1):
mu!=!mean(vals)
if!len(vals)!<!2:
return!0.0
num!=!0.0
for!x!in!vals:
num!+=!(x!- mu)**2
denom =!len(vals)!- sd_corr
return!math.sqrt(num!/!denom)
Range,$advanced$assignments,$logical$statements,$
printing,$and$function$definitions
Advanced(function(signatures
def$zscore(vals,$sd_corr=1):
mu$=$mean(vals)
sigma$=$sd(vals,$sd_corr=sd_corr)
normed$=$[]
for$x$in$vals:
normed.append((x$- mu)$/$sigma)
return$normed
```

### 한국어 요약 결과

Range,$advanced$assignments,$logical$statements. sigma$=$sd_core(vals,    sd_   printing,$and$function(signatures
def$zscore,$sc_corr(   def,  syrr
   (muggle, alath.sqrt(num!/!d


---

## Unit 29 — page_30 (page)

### 원본 텍스트

```
Basic$file$and$CSV$reading$and$writing;
os.path basics
Basic(file(reading(and(writing
§ To$open$a$text$file$with$name filename and$read$its$contents$into$a$string$
called contents:
•$with$open(filename)$as$f:
$$$$$$contents$=$f.read()$
§$to$write$a$string s to$a$file filename:
•$with$open(filename,$'wt')$as$f:
$$$$$$f.write(s)$
§$To$efficiently$open$a$(potentially$very$large)$file$and$read$it$line-by-line$without$
first$reading$all$of$it$into$memory:
•$with$open(filename)$as$f:
$$$$$$for$line$in$f:
$$$$$$$$$$line$##$This$is$a$string,$including$the$final$new$line$character.
```

### 한국어 요약 결과

Basic(file$a$a, basic$afle$, and$read$ legle$contents$ seading$A$f.f.read()$as$
$$$A.sele$$, §$$of$.filename,$'write(s)$A,  
$$.path.fle,  sele.fath basy:
   $$To$effic


---

## Unit 30 — page_31 (page)

### 원본 텍스트

```
Basic$file$and$CSV$reading$and$writing;
os.path basics
Common(csv(library(operations
§ Yield%lists
• with%open(filename)%as%f:
for%row%in%csv.reader(f):
#%do%something%with%`row`,%a%list%of%str
§ Yield%dicts
• with%open(filename)%as%f:
for%d%in%csv.DictReader(f):
#%do%something%with%`d`,%a%dict mapping
#%values%from%line%0%to%values%for%the
#%current%row.
§ Abstracting%out%the%delimiter
• with%open(filename)%as%f:
for%d%in%csv.DictReader(f,%delimiter=delimiter):
§ Writing%a%CSV%file
• with%open(filename,%'wt')%as%f:
writer%=%csv.writer(f)
writer.writerows(rows)
#%Alternatively,%write%the%rows%one%at%a%time:
#%for%row%in%rows:
#%writer.writerow(rows)
```

### 한국어 요약 결과

Common(csv(library(operations))%path basics, and with%open(filename)%as%f:
for%do%.DictReader(f):
" "ho%something%from%"row,%a%dict mapping, " "%Alternatively,%write%the%row. rows


---

## Unit 31 — page_32 (page)

### 원본 텍스트

```
Basic$file$and$CSV$reading$and$writing;
os.path basics
Why(use(csv(at(all?
§ It#seems#at#first#like csv is#unnecessary#overhead.#After#all#you#can#create#a#CSV#row#
with ','.join(row) and#parse#with line.strip().split(',’).
• Consider#these#rows:
• rows#=#[#["Earth,#Wind,#and#Fire",#1969],
["Peter,#Paul#and#Mary",#1961],
["Guns#N'#Roses",#1985],
['"Weird#Al"#Yankovic',#1976]]
§ If#you#write#these#with#your#the#simple#method#(after#first#converting#the#years#to str!),#you#
get#a#file#with#contents:
• Earth,#Wind,#and#Fire,1969
Peter,#Paul#and#Mary,1961
Guns#N'#Roses,1985
"Weird#Al"#Yankovic,1976
• which#is#now#ambiguous#about#how#it#should#be#parsed.
§ If#you#instead#use csv.writer,#you#get
• "Earth,#Wind,#and#Fire",1969
"Peter,#Paul#and#Mary",1961
Guns#N'#Roses,1985
"""Weird#Al""#Yankovic",1976
• which#cannot#be#read#with#the#simple#method line.strip().split(','),#but#
with csv.reader will#process#accurately.
```

### 한국어 요약 결과

',ider#these#rows:
'.join(row) and#parse#with line.strip().split(',').'   row s:
"Earth,#Wind,#and#Fire,1969, "you#contents: " " ", " "
"Peter,#Paul#Mary, 1961
"Guns#N'#Roses,1985
"


---

## Unit 32 — page_33 (page)

### 원본 텍스트

```
Basic$file$and$CSV$reading$and$writing;
os.path basics
The(os library
§ The%Python os library%has%lots%of%functionality%for%dealing%with%the%operating%
system.
• It's%sublibrary os.path contains%methods%for%working%with%filenames.
§ I%suggest%getting%in%the%habit%of%using os.path.join to%specify%filenames.
• It%creates%a%string%from%the%string%arguments%you%give%it,%but%the%delimiter%
between%them%is%the%appropriate%one%for%the%current%operating%system.
§ #%Goes%up%one%level%with%".."%and%then%gives%the%base%filename:
• os.path.join("..",%"foo.txt")
§ #%Goes%up%one%level%and%then%down%into%the%directory%"bar",%and%then%gives%the%
base%filename:
• os.path.join("..",%"bar",%"foo.txt")
§ #%Goes%down%two%levels%and%then%gives%the%base%filename:
• os.path.join("bar1",%"bar2"%"foo.txt")
§ The%fact%that%the%separation%character%differs%across%operating%system%motivates%
using os.path methods%for%any%operation%on%filenames%that%depends%on%this%
character.%Common%cases: os.path.basename, os.path.split, os.path.splitext.
```

### 한국어 요약 결과

Syse%sublibrary os.path contains%methods%for%working%the%delimiter%filenames, and I%suggest%getting%of%habit%sath.join to%specify%fith.sele.seoin. and It%creates%a%string%from%ahableblevel%th


---

## Unit 33 — page_34 (page)

### 원본 텍스트

```
Iterators$and$generators
Iterators
§ You$can$turn$str,$list,$tuple,$dict,$and$other$iterables into$iterators$with$
the iter built-in.
§ The next built-in$will$return$the$next$item$from$the$iterator:
• vals =$[1,2,3]
i =$iter(vals)
next(i)$#$1
next(i)$#$2
next(i)$#$3
---------------------------------------------------------------------------
StopIteration Traceback$(most$recent$call$last)
• As$the StopIteration error$shows,$the$iterator$is$"used$up"$when$we've$
moved$through$all$its$members.
```

### 한국어 요약 결과

StopIteration Traceback$(most$return$) error$shows,$the$iterator$is$"used$up"$we've$
next(i)$#$2
'Stop Iteration Soft built-in,  " " ", As.  ", ",  St pile, iteration  ',   As,  ' (St


---

## Unit 34 — page_35 (page)

### 원본 텍스트

```
Iterators$and$generators
File(objects(as(iterators
§ You$can$call next on$file$objects:
• f$=$open("alice.txt")
next(f)$#$'\ufeffThe Project$Gutenberg$EBook of$Alice$in$Wonderland,$
by$Lewis$Carroll\n’
next(f)$#$'\n’
§ When$you$use$our$standard$idiom$for$opening$a$file$and$moving$through$its$
lines,$you$are$relying$on$the$fact$that$file$objects$are$iterators:
• with$open(filename)$as$f:
for$line$in$f:
#$Do$something$with$`line`
• This$is$a$memory-efficient$way$to$read$through$the$file,$because$it$never$
reads$the$whole$file$into$memory.$This$is$therefore$preferred$in$contexts$
where$line-by-line$processing$meets$your$needs.
```

### 한국어 요약 결과

LyeffThe Project$Gutenberg$EBook of$Alice$File$Gose$Line,$
file(objele$)$'fle'for'f:
for$something$as$ "line "
 "gle("alice.txt, on$fle.tole$ sele,$' preferred$in$'   le,


---

## Unit 35 — page_36 (page)

### 원본 텍스트

```
Iterators$and$generators
Custom(generators
§ We$often$want$to$read$in$files$line-by-line$and$do$something$with$those$lines.$
For$example,$with$a$CSV,$you$might$want$to$process$the$column$values$in$
complex$ways.$Custom$generators$provide$a$scalable,$intuitive$way$to$do$this.$
Here's$a$simple$example:
• def$uppercase_reader(filename):
with$open(filename)$as$f:
for$line$in$f:
line$=$line.upper()$##$Presumably$you$would$do$something$more
yield$line
§ The$crucial$piece$is$using yield rather$than return.$With$the$above,$
calling next will$iteratively$yield$uppercased$lines,$and$using$a$for-loop$will$move$
loop$over$uppercased$lines:
• for$line$in$uppercase_reader(filename):
#$Do$something$with$`line`
```

### 한국어 요약 결과

Weoften$files$fo$scalable,$you$might$process$the$column$values$ complex$generators, and for$osed$Lines.$
''s.$' s$a$simple,  def$uppercase_reader(filename)$as$f:
for$line$in$f:0
f


---

## Unit 36 — page_37 (page)

### 원본 텍스트

```
Iterators$and$generators
Custom(generators
§ We$often$want$to$read$in$files$line-by-line$and$do$something$with$those$lines.$
For$example,$with$a$CSV,$you$might$want$to$process$the$column$values$in$
complex$ways.$Custom$generators$provide$a$scalable,$intuitive$way$to$do$this.$
Here's$a$simple$example:
• def$uppercase_reader(filename):
with$open(filename)$as$f:
for$line$in$f:
line$=$line.upper()$##$Presumably$you$would$do$something$more
yield$line
§ The$crucial$piece$is$using yield rather$than return.$With$the$above,$
calling next will$iteratively$yield$uppercased$lines,$and$using$a$for-loop$will$move$
loop$over$uppercased$lines:
• for$line$in$uppercase_reader(filename):
#$Do$something$with$`line`
```

### 한국어 요약 결과

Weoften$files$fo$scalable,$you$might$process$the$column$values$ complex$generators, and for$osed$Lines.$
''s.$' s$a$simple,  def$uppercase_reader(filename)$as$f:
for$line$in$f:0
f


---

## Unit 37 — page_38 (page)

### 원본 텍스트

```
Introduction$to$regular$expressions
import(re
§ Quantifiers
• #$Match$a
re.search(r"a",$"a")$##$Matches$a
re.search(r"a",$"b")$##$No$Match
#$Match$0$or$1$a
re.search(r"a?",$"aa")$##$Matches$a
re.search(r"a?",$"")$##$Matches$’’
#$Match$0$or$more$a
re.search(r"a*",$"aaa")$##$Matches$aaa
re.search(r"a*",$"")$##$Matches$’’
#$Match$1$or$more$a
re.search(r"a+",$"a")$##$Matches$a
re.search(r"a+",$"")$##$No$match
```

### 한국어 요약 결과

Introduction$to$regular$expressions
import(re.search(r"a,$")$##$Matches$a
re. seachseaa
(r'ach(aaa, "$'' ' ' ''''  ‘#$ Matchse$'  ' '#$more$' 
#$(Match$0$or$oreaseare$a,reasea,sear


---

## Unit 38 — page_39 (page)

### 원본 텍스트

```
Introduction$to$regular$expressions
import(re
§ Quantifiers
• #$Match$2$to$5$a$in$a$row;$first$and/or$second$bounds$can$be$left$off$
re.search(r"a{2,5}",$"aaa")$##$Matches$aaa
re.search(r"a{2,5}",$"a")$##$No$match
re.search(r"a{2,5}",$"aaaaaaa")$##$Matches$the$first$5$a
§ Case-insensitive$search
• re.search(r"a+",$"A",$re.I)$##$Matches$A
re.search(r"a+",$"A")$##$No$match
§ Sets$of$characters
• #$Match$any$of$the$characters$inside$[]:
$$re.search(r"[abc]",$"b")##$Matches$b
$$#$Match$1$or$more$characters$inside$[]$in$a$row,$any$order:
$$re.search(r"[abc]+",$"bac")$##$Matches$bac
$$#$Compare$with$exact$string$match:
$$re.search(r"abc",$"bac")$##$No$match
$$#$Match$any$character$that$*isn't*$in$the$set$consisting$of$a,$b,$c:
$$re.search(r"[^abc]+",$"bac")
```

### 한국어 요약 결과

Match$2$first$a$second$seft$off$
re.search(r"a{2,5},$"a,$A, re.I)$##$No$match
$$Match, left,$aaase.$A
$#$Mof$A


---

## Unit 39 — page_40 (page)

### 원본 텍스트

```
Introduction$to$regular$expressions
import(re
§ Grouping$with$parentheses
• #$Matches$ab$and$then$1$or$more$c:
re.search(r"abc+",$"abcccccc")$##$Matches$abcccccc
#$Matches$1$or$more$of$the$exact$string$abc:
re.search(r"(abc)+",$"abcabcc")$##$Matches$abcabc
#$Matches$abc or$xyz
re.search(r"(abc|xyz)",$"xyzabc")$##$Matches$xyz
§ Character$groups
• #$Period$matches$any$character$re.search(r".",$"abc")$##$Matches$abc.
#$Matches$1$or$more$alphanumeric$characters$in$a$row:
re.search(r"\w+",$"abc")$##$Matches$abc.
#$This$is$roughly$equivalent$to$the$above,$but$\w$is$more$permissive$#$
with$Unicode:
re.search(r"[a-zA-Z0-9_]+",$"abc")$##$Matches$abc
#$Matches$1$or$more$digits:
re.search(r"\d+",$"a000b")$##$Matches$000
#$Matches$any$kind$of$whitepace
re.search(r"\s",$"a$b")$
```

### 한국어 요약 결과

Grsearch(r"(abcccess))$#$Matches$abcabc
re.searse abc(r,abc,$"abc") or$라면,$##$Faracter$groups
_$Period$my$matchs$charact.sehes$heres$amyse
_ or.seaches. orphanumeric$a$row:
re


---

## Unit 40 — page_41 (page)

### 원본 텍스트

```
Introduction$to$regular$expressions
import(re
§ Some$special$characters
• ^ matches$the$start$of$the$string.$(Inside [],$it$is$negation!)
• $ matches$the$end$of$the$string.
• To$match$any$special$character,$including$quantifiers,$braces,$etc.,$add$a$
preceding$backslash.
```

### 한국어 요약 결과

Tomatch$any$special$character,$including$quantifiers,$braces,$etc.,$add$a$
preceding$backslash.$의 경우 ",$it$is$negation,  ", $ matches$regular$the$string,    To.,  Matchelle,$pression,$s,$


---

## Unit 41 — page_42 (page)

### 원본 텍스트

```
Introduction$to$regular$expressions
Matcher(objects(are(True(in(conditionals
§ Conditionals$are$very$common$environments$for$regexs,$since$one$is$very$often$
testing$strings$based$on$the$regex$pattern:
• if$re.search(r"L",$"aLa"):
print("Match!")
else:
print("No$match!")
Capturing(groups(and(match(objects
§ m$=$re.search(r"(R)",$texts[0],$re.I)
m.start()$##$First$index$of$the$match
m.end()$##$Final$index$of$the$match
m.groups()$##$Returns$('R',)
Compiling(regular(expressions
§ regex$=$re.compile(r”a+”,$re.I)
regex.search("bAab")
```

### 한국어 요약 결과

Matcher(objects)는 if$re.search(r"L,$"a,"):
print("Match!")
m.start()$##$First$Af$of$("bAab")$regex$Returns$Aguring(groups,  regular(expressions, compiling(regle,  "R, re.I,


---

## Unit 42 — page_43 (page)

### 원본 텍스트

```
Introduction$to$regular$expressions
Reg(exercises(1
§ Words$that$begin$with$a$capital$letter.
§ Words$that$contain$a$medial$capital$letter.
§ Words$that$contain$a$hyphen.
§ Words$that$begin$with$exactly$two$consonants,$end$with$exactly$two$
consonants,$and$have$exactly$three$vowels$('a','e','i','o','u')$in$between.$Case-
insensitive.
§ Words$that$end$either$in$'ous'$or$in$'ary'.$Case-insensitive.$(How$many$of$these$
are$adjectives$derived$from$nouns?)
§ Words$that$contain$the$vowels$'a',$'e',$'i',$'o',$and$'u',$in$that$order,$perhaps$
with$other$characters$in$between.$Case-insensitive.
§ Same$as$above,$but$make$sure$the$other$characters$aren't$vowels.
```

### 한국어 요약 결과

Words$that$contain$a$capital$letter.    G,  Reg(expressions,   Insensitive.$ How$ seg$sure$s.$but$other$ above,$byphen.$ Same$ legg.$How.$af$of$  sese-in$'ase.$ ' '.$' letle


---

## Unit 43 — page_44 (page)

### 원본 텍스트

```
Introduction$to$regular$expressions
Reg(exercises(2
§ Words$with$an$even$number$of$a's$in$them$(0,$2,$4,$...).$Case-insensitive.
§ Words$that$begin$and$end$with$the$same$letter.$(For$this,$you$need$to$use$
capturing$groups: re.compile(r"(.)x\1") is$a$regex$for$any$string$containing$a$
character,$'x',$and$then$the$first$character$again.)
§ Words$with$the$longest$sequence$of$the$same$letter$in$a$row$in$the$data.$
Case-insensitive.
§ Words$that$have$two$or$more$dotted$letters$in$a$row.$Case-insensitive.
§ Same$as$the$above,$but$allow$hyphens$between$the$dotted$letters,$and$don't$
count$hyphens$towards$the$length.
```

### 한국어 요약 결과

Samds$ sequence$of$same$letters,$'x',$'don't$' setter.$'the$'s$'sele, re.compile(r"(.)x\1") is$ase letted$.$ (  segg(regg.$ 'sele.segle$ regle.    ( legg,$ 'gg$' s',$and


---

## Unit 44 — page_45 (page)

### 원본 텍스트

```
More$on$regular$expressions
Negated(character(groups
§ For$each$of$the$character$group$abbreviations,$capitalizing$it$will$created$its$
negated$version:
• \w matches$all$alphanumeric$characters; \W matches$everything$else
• \d matches$all$digits; \D matches$everything$else
• \s matches$all$whitespace; \S matches$everything$else
Greedy(and(non-greedy(matching
§ By$default,$the$quantifiers$will$match$greedily.$To$turn$this$off,$add$a$question$
mark:
• re.search(r".+,",$"aa,bb,")$##$Matches$'aa,bb,’
• re.search(r".+?,",$"aa,bb,")$##$Matches$'aa,'
```

### 한국어 요약 결과

More$on$regular$expressions, \s matches$all$alphanumeric$character$bbreaed$its$
negated$version:
 \se,   " ",  By$default,$the$quantifiers$will$match$greedily.$To$turn$off,$add$a$question


---

## Unit 45 — page_46 (page)

### 원본 텍스트

```
More$on$regular$expressions
Turning(off(capturing(groups
§ Parentheses$are$used$both$for$grouping$and$for$capturing.$If$you$want$to$use$
them$just$for$grouping$­ no$capturing$­ then$start$the$group$with ?:
• re.search(r"(a)b",$"ab").group(1)$##$Returns$’a’
• re.search(r"(?:a)b",$"ab").group(1)$##$Error,$because$there$isn't$a$group$
1.
String(substitutions
§$re.sub will$allow$you$to$replace$matches$with$something$else:
•$re.sub(r"abc",$r"XYZ",$"abc")$
§$You$can$refer$to$ca$groups$using \1, \2,$etc.:
•$re.sub(r"(a)(b)",$r"\2\1",$"abab")
§$Notice$the$use$of$raw$strings$for$the$replacement.$This$is$primarily$due$to$the$
backslash.$I$try$always$to$use$a$raw$string$for$this$argument.
```

### 한국어 요약 결과

Parentheses$used$for$grouping$hen$gpressions, re.search(r"(a)a,$because$something$'a, le.se.sub will$allow$you$replace$matches$aselece$ayse$ho$alwayslesh.$I$to$the$" leggring.  
$


---

## Unit 46 — page_47 (page)

### 원본 텍스트

```
More$on$regular$expressions
Using(findall
§ The$method findall is$a$simple$variant$of search in$which$all$the$matches$are$
returned$as$a$list:
• re.findall(r"abc",$"abcabc")$##$['abc',$'abc’]
§ A$common$gotcha$is$that,$if$there$are$capturing$groups,$then findall will$
include$only$them:
• re.findall(r"(ab|AB)c",$"abcABc")$##$['ab',$'AB’]
§ This$is$a$situation$in$which$we$often$want$to$turn$off$the$grouping:
• re.findall(r"(?:ab|AB)c",$"abcABc")$##$['abc',$'ABc']
To$Be$Discussed$further
```

### 한국어 요약 결과

Morethod findall is$simple$variant$of search in$which$all$as$a$list, re.findall(r"(abcABc")$##$['abc',$'AB']
 This$is$A$situation$in$we$wften$to$turn$off$the$groups,$aft$then f


---

## Unit 47 — page_48 (page)

### 원본 텍스트

```
Exceptions
The(semantics(of(exceptions
§ Python$has$a$lot$of built-in$exceptions with$semantic$guidelines$that$you$
should$try$to$follow$when$raising$exceptions$in$your$own$programs.
Raising(exceptions
§ The raise built-in$lets$you$raise$specific$exceptions:
• def$palindrome_detector(s):
if$not$isinstance(s,$str):
raise$TypeError("palindrome_detector expects$type$str")
s$=$s.lower().replace("$",$"")
return$s$==$s[::-1]
```

### 한국어 요약 결과

Python$has$a$lot$of built-in$exceptions with$semantic$guidelines$ayn$programs, Raising("palindrome_detector expects$type$stror($s.lower().replace("$",$"")
return$s$==$s[[[:::$$")


---

## Unit 48 — page_49 (page)

### 원본 텍스트

```
Exceptions
Using(assert
§ The assert built-in$can$be$used$to$raise$an AssertionError.$It$is$very$commonly$
used$in$writing$unit$tests:
• def$test_palindrome_detector():
ex$=$'Lisa$Bonet$ate$no$basil’
expected$=$True
result$=$palindrome_detector(ex)
assert$result$==$expected,$"For$'{}',$expected${};$got${}".format(ex,$
expected,$result)
§ You$can$think$of$the$final$line$as$a$short$version$of
• if$result$!=$expected:
raise$AssertionError("For$'{}',$expected${};$got${}".format(ex,$expected,$
result))
```

### 한국어 요약 결과

sef$final$Line$short$Asert, if$result$$AssertionError.format(ex,$${}',$got${{$""$("$,$"   f,$
expected,$Af
if$.fglet$Ague,$(if$$$.if$,  you$can$think$of$the$ff$


---

## Unit 49 — page_50 (page)

### 원본 텍스트

```
Exceptions
Basic(try(…(except
§ For$example,$the$following$code$seems$to$make$the$assumption$that
• the$input$consists$of$a$list$of$things$that$can$be$turned$into$an$int,
and$it$uses$exception$handling$to$tell$the$user$about$any$instances$in$
which$that$assumption$proves$false.
• import$warnings
def$int_converter(vals):
new_vals =$[]
for$x$in$vals:
try:
x$=$int(x)
new_vals.append(x)
except$ValueError:
warnings.warn("Couldn't$convert${}".format(x))
return$new_vals
```

### 한국어 요약 결과

Exple,$following$seems$the$assumption$false, import$warnings.format(x$in$vals:
try:
x$=$int(x) x$(x.append(x)
except$ValueError:    ("Couldn't$convert${}"   ",  "  " (".f


---

## Unit 50 — page_51 (page)

### 원본 텍스트

```
Exceptions
else(clauses
§ If$you$want$something$specific$to$happen$where$no$exception$is$raised,$you$
can$optionally$include$an else clause:
• def$int_converter_else(vals):
new_vals =$[]
for$x$in$vals:
try:
x$=$int(x)
except$ValueError:
warnings.warn("Couldn't$convert${}".format(x))
else:
new_vals.append(x)
return$new_vals
```

### 한국어 요약 결과

def$int_converter_else(vals):
".format(x$(x) ",    ", ", you.warn(",",  "   s$("   plet$,  s)   .  else:
  leturn$new_valse.append(x)
   if$.  seley(" ("  s)
  ".try,


---

## Unit 51 — page_52 (page)

### 원본 텍스트

```
Exceptions
finally(clauses
§ Just$to$round$this$out,$there$is$also$an$optional finally clause,$where$you$can$
specify$code$that$will$execute$whether$an$exception$was$raised$or$not:
• def$int_converter_else_finally(vals):
new_vals =$[]
for$x$in$vals:
try:
x$=$int(x)
except$ValueError:
warnings.warn("Couldn't$convert${}".format(x))
else:
new_vals.append(x)
finally:
print(“Handled${}”.format(x))
return$new_vals
```

### 한국어 요약 결과

Exceptions,  def$int_converter_else_finally(vals):
".frint(“Handled${}”.format(x) :
return$new_valse.file$inse:
try:
except$ValueError:
warnings("Couldn't$conval(""s$(".


---

## Unit 52 — page_53 (page)

### 원본 텍스트

```
Exceptions
Deliberate(exceptions
§ Here's$an$example$of$exception$handling$used$as$a$strategy$for$adding$new$
keys$to$a$dictionary:
• def$counter_tryexcept(vals):
d$=${}
for$x$in$vals:
try:
d[x]$+=$1
except$KeyError:
d[x]$=$1
return$d
```

### 한국어 요약 결과

Here's$an$example$of$a$strategy$for$adding$dictionary: def$counter_tryexcept(vals):
d$=${}
dgpt$KeyError:
return$dire$dals$$Ag$\$1
d[x]$A.y$Ry:    d[xc$A,   .


---

## Unit 53 — page_54 (page)

### 원본 텍스트

```
Sorting
Sorting(objects(of(different(types
§ sorted(['b',$'c',$'a'])$#$Returns$['a',$'b',$'c’]
§ sorted("bca")$#$Returns$['a',$'b',$'c’]
§ sorted(('b',$'c',$'a’))$#$Returns$['a',$'b',$'c’]
§ #$For$dicts,$sorting$is$by$keys:
d$=${'b':$True,$'c':$False,$'a':$True}
sorted(d)$#$Returns$['a',$'b',$'c’]
#$Sorting$dict items:
d$=${'b':$True,$'c':$False,$'a':$True}
sorted(d.items())$#$Returns$[('a',$True),$('b',$True),$('c',$False)]
```

### 한국어 요약 결과

Sorting(objects, sorting$'c',$'a')$#$Returns$['a',$ 'b',$(''c']
 § sorted('a,$'b,$ 'c' items())   " ",  ", ", ',$A,$,$('c'],   ($Sorting.diys,  c'    different(types()  sort


---

## Unit 54 — page_55 (page)

### 원본 텍스트

```
Sorting
Reverse
§ Use$the reverse keyword;$works$with$any$sortable$object:
sorted(['b',$'c',$'a'],$reverse=True)$#$Returns$['c',$'b',$'a’]
Sorting(in(other(ways
§ sorted(['aaa',$'cc',$'b'],$key=len)$#$Returns$['b',$'cc',$'aaa’]
§ sorted(['aaa',$'cc',$'b'],$key=len,$reverse=True)$#$Returns$['aaa',$'cc',$‘b’]
§ def$vowel_count(x):
import$re$vowels$=$"aeiou”
regex$=$re.compile(r"[{}]".format(vowels),$re.I)
m$=$regex.findall(x)
return$len(m)
§ sorted(['Xe',$'XaXaX',$'b'],$key=vowel_count)$#$Returns$['b',$'Xe',$'XaXaX']
```

### 한국어 요약 결과

Sorting(other(ways)) sorted(['aaa,$'cc',$'a'],$regex.findall(x)
'aeile(".format(vowels),$re.I.I(m$=$ref.file.filmed('a,'c'' ',$key=len(m)
''Xe'$'XaXaI(''' a,$',$


---

